﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VkNet;
using VkNet.Model;
using VkNet.Model.RequestParams;

namespace praktika1
{
	public partial class Form2 : Form
	{
		public Form2()
		{
			InitializeComponent();
			
		}

		private void button1_Click(object sender, EventArgs e)
		{
			var api_group = new VkApi();
			api_group.Authorize(new ApiAuthParams
			{
				AccessToken = textBox1.Text
			});
			var api_user = new VkApi();

			api_user.Authorize(new ApiAuthParams
			{

				AccessToken = textBox4.Text
			});
			var getFollowers = api_group.Groups.GetMembers(new GroupsGetMembersParams()
			{
				GroupId = textBox2.Text,
				Fields = VkNet.Enums.Filters.UsersFields.FirstNameAbl
			});
			foreach (User user in getFollowers)
				listBox1.Items.Add(Encoding.UTF8.GetString(Encoding.Default.GetBytes(user.FirstName + " " + user.LastName)));
			//0656a97f252b6b594654788985f7b9f08d4213a83b58ece16cb7afafb40e1d1c06b478a4db529ec195e0c
			var List = api_user.Wall.Get(new WallGetParams
			{
				OwnerId = Convert.ToInt32(textBox3.Text)
			});
			listBox2.Items.Add(Encoding.UTF8.GetString(Encoding.Default.GetBytes(List.WallPosts.First().Text)));
			var repost = api_user.Wall.Repost(@object: $"wall{List.WallPosts.First().OwnerId}_{List.WallPosts.First().Id}", message: "testirovka", groupId: 131494720, markAsAds: false);	

			
		}
	}
}
