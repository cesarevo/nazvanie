﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VkNet;
using VkNet.Model;
using VkNet.Model.RequestParams;
using System.IO;

namespace praktika1
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			var api_user = new VkApi();
			api_user.Authorize(new ApiAuthParams
			{
				AccessToken = textBox1.Text
			});
			var getFriends = api_user.Friends.Get(new VkNet.Model.RequestParams.FriendsGetParams
			{
				Fields = VkNet.Enums.Filters.ProfileFields.All
			});
			var get = api_user.Wall.Get(new WallGetParams());
			if (radioButton1.Checked == true)
			{
				foreach (User user in getFriends)
					listBox1.Items.Add(Encoding.UTF8.GetString(Encoding.Default.GetBytes(user.FirstName + " " + user.LastName)));
			}
			else if (radioButton2.Checked == true)
			{
				foreach (var WallPosts in get.WallPosts)
					listBox2.Items.Add(Encoding.UTF8.GetString(Encoding.Default.GetBytes(Convert.ToString(WallPosts.Text))));
			}
			
			else if (radioButton4.Checked == true)
			{
				int currentYear = DateTime.Now.Year; //переменная текущего года
				var ListofAges = new List<int>(); //список годов рождения
				var ActualAges = new List<int>(); //список возрастов
				int averageAge = 0; //средний возраст
				foreach (User user in getFriends) //цикл сбора годов рождения
				{
					if (user.BirthDate == null) //проверка на нулл
					{
						continue;
					}
					else if (user.BirthDate.Length > 5) //проверка на то, имеется ли год
					{
						int swap = DateTime.Parse(user.BirthDate).Year; //если есть, конвертирует последние 4 символа стринга, то есть год, в интегер
						ListofAges.Add(swap); //добавляет год в список
					}

					
				}

				for (int i = 0; i < ListofAges.Count; i++) //цикл создания возрастов
				{
					int ye = currentYear - ListofAges[i]; //вычитает текущий год из года в списке
					ActualAges.Add(ye); //добавляет полученный возраст в список возрастов
					listBox3.Items.Add(ye); //выписывает полученный возраст в листбокс
				}


				for (int i = 0; i < ActualAges.Count; i++) //цикл сложения возрастов
				{
					averageAge += ActualAges[i]; //складывает все возраста
				}

				averageAge = averageAge / ActualAges.Count; //делит на количество возрастов, получает искомое

				listBox4.Items.Add(averageAge); //показыва
			}


			/*var getFriends = api_user.Friends.Get(new VkNet.Model.RequestParams.FriendsGetParams
			{
				Fields = VkNet.Enums.Filters.ProfileFields.All
			});
			foreach (User user in getFriends)
			{
				
				listBox5.Items.Add(Encoding.UTF8.GetString(Encoding.Default.GetBytes(user.Music)));
				//listBox4.Items.Add(Encoding.UTF8.GetString(Encoding.Default.GetBytes(Convert.ToString(user.BirthDate))));
			}
			*/

			//284aa3be6e17406365e78451e2562d0db27f8b8a2bf7627570d55850c678c74be2a05675f32755e2f3590	


			//замечание: при получении информации через Friends.Get даты рождения выдаются стрингом
			//и если дата рождения не указана, выдается null, поэтому есть проверка на него
			//также в дате рождения может не быть года, поэтому стоит проверка на количество символов в стринге

			
			if (textBox2.Text!="")
			{
				var UserInfo = api_user.Users.Get(new long[] { Convert.ToInt32(textBox2.Text) }, VkNet.Enums.Filters.ProfileFields.Photo200Orig).FirstOrDefault();
				pictureBox1.ImageLocation = UserInfo.Photo200Orig.OriginalString;
			}
			
			

		}

		/*private void button2_Click(object sender, EventArgs e)
		{
			var api_group = new VkApi();
			api_group.Authorize(new ApiAuthParams
			{
				AccessToken = textBox2.Text
			});
			var getFollowers = api_group.Groups.GetMembers(new GroupsGetMembersParams()
			{
				GroupId = textBox3.Text,
				Fields = VkNet.Enums.Filters.UsersFields.FirstNameAbl
			});
			foreach (User user in getFollowers)
				listBox3.Items.Add(Encoding.UTF8.GetString(Encoding.Default.GetBytes(user.FirstName+""+user.LastName)));
		}*/

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			
		}

		private void radioButton2_CheckedChanged(object sender, EventArgs e)
		{
			
		}

		private void radioButton3_CheckedChanged(object sender, EventArgs e)
		{
			
		}
	}
}
